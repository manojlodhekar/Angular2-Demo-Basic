export class IEmployee{

    firstName: string;
	lastName: string;
	companyName: string;
	image: string;
	address: string;
	profile: string;
	age: number;
    email:string;
	employeeNumber: number;
}