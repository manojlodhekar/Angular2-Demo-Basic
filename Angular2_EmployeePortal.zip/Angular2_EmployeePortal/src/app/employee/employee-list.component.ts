import { Component, OnInit } from '@angular/core';
import { IEmployee } from './Employee';
import { EmployeeService } from '../services/employee.service.component';
import { Router } from '@angular/router';

@Component({
    selector: 'emp-list',
    templateUrl : '../templates/employee-list.component.html',
    styleUrls: ['../../data/employees/styles/employee.component.css']
})
export class EmployeeListComponent implements OnInit{

    pageTitle = "Employee List";
    employeeList:IEmployee[];
    errorMessage:string;
    searchBy:string;
    constructor(private _employeeService: EmployeeService, private _router:Router){}
    ngOnInit():void{
        this._employeeService.getEmployeeList()
                            .subscribe(response => this.employeeList = response, error => this.errorMessage = error);
    }
    onEmployeeItemClicked(selectedEmployee:IEmployee):void{
        console.log("selectedEmployee1443434 = " + selectedEmployee.firstName);
        this._router.navigate(['/employee', selectedEmployee.employeeNumber ]);
    }
    
}