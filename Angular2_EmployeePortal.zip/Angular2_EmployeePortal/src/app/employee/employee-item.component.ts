import { Component, Input, Output, OnChanges, OnInit, EventEmitter } from '@angular/core';
import { IEmployee } from './Employee';

@Component({
    selector: 'emp-item',
    templateUrl : '../templates/employee-item.component.html',
    styleUrls: ['../../data/employees/styles/employee.component.css']
})

export class EmployeeItemComponent implements OnChanges{

@Input() employeeItem:IEmployee[];
@Output() employeeItemClicked:EventEmitter<string> = new EventEmitter<string>();
    
    employeeInfo:IEmployee[];
    ngOnChanges():void{
        this.employeeInfo = this.employeeItem;
    }
    
    employeeClicked(employee:IEmployee):void{
        console.log("Employees last name  = " + employee.lastName);
        this.employeeItemClicked.emit(`this.employeeItem:IEmployee[]`);

    }

}