import { Pipe, PipeTransform } from '@angular/core';
import { IEmployee } from './employee';
@Pipe({
   name: 'employeeFilter'

})
export class EmployeeFilterPipe implements PipeTransform{

    //employeeList
    transform(values:IEmployee[], searchBy:string):IEmployee[]{
        searchBy = searchBy ? searchBy.toLocaleLowerCase() : null;
        return searchBy ? values.filter((employee:IEmployee) => employee.firstName.toLocaleLowerCase().indexOf(searchBy) > -1) : values;
    }
}