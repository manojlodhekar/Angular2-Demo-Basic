import { Component, OnInit } from '@angular/core';
import { IEmployee } from './employee';
import { EmployeeService } from '../services/employee.service.component';
import { Router, ActivatedRoute} from '@angular/router';
import { Subscription } from 'rxjs/Subscription';

@Component({
    templateUrl : '../templates/employee-details.component.html',
})

export class EmployeeDetailsComponent implements OnInit{

    title:string;
    subs:Subscription;
    employee:IEmployee[];
    tt:IEmployee[];
    errorMessage:string;
    constructor(private _employeeService:EmployeeService, 
                private _route:ActivatedRoute,
                private _router:Router){}

    ngOnInit():void{
        this.subs = this._route.params.subscribe(
            params => {
                let id = + params['id'];
                this.employeeById(id);
            }
        )
    }

    employeeById(id:number):void{
        this.title = "This is " + id;
        this._employeeService.getEmployeeById(id).subscribe(
            employee => {
                this.employee = employee;
                this.title = `Details of '${employee['firstName']} ${employee['lastName']}'`;
        },
            error => this.errorMessage = <any>error
        )
    }
    onBack():void{
        this._router.navigate(['/employees']);
    }

}