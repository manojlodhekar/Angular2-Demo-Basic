import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { EmployeeListComponent } from './employee/employee-list.component';
import { EmployeeDetailsComponent } from './employee/employee-details.component';
import { WelcomeComponent } from './home/welcome.component';

const routes:Routes = [
    { path:'', redirectTo:'welcome', pathMatch: 'full' },
    { path:'welcome', component:WelcomeComponent },
    { path:'employees', component:EmployeeListComponent },
    { path: 'employee/:id', component:EmployeeDetailsComponent}
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes)
  ],
  exports:[
      RouterModule
  ]
})
export class AppRountingModule { }
export const routingComponent = [EmployeeListComponent, EmployeeDetailsComponent, WelcomeComponent];