import { Component } from '@angular/core';
import { Router } from '@angular/router';
@Component({
    templateUrl: './welcome.component.html'
    //templateUrl : '../templates/employee-list.component.html',
})
export class WelcomeComponent {
    public pageTitle: string = 'Welcome to EmployeePortal in Angular 2.';
    constructor(private _router:Router){}
    onStart():void{
        this._router.navigate(['/employees']);

    }
}
