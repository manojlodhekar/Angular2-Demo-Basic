import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { IEmployee } from '../employee/Employee';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/throw';


@Injectable()
export class EmployeeService{

private employeeUrl:string = '../../src/data/employees/data/employee.json';
constructor(private _http:Http){}

getEmployeeList():Observable<IEmployee[]>{
    return this._http.get(this.employeeUrl)
    .map((response:Response) => <IEmployee[]> response.json()) 
    .do(data => console.log("All = " + JSON.stringify(data)))
    .catch(this.handleError);
}

getEmployeeById(empid:number):Observable<IEmployee[]>{
    return this.getEmployeeList()
            .map((employee: IEmployee[]) => employee.find(p => p.employeeNumber === empid)); 
}

    private handleError(error:Response){
        console.error(error);
        return Observable.throw(error.json().error || 'server Error');
    }

}