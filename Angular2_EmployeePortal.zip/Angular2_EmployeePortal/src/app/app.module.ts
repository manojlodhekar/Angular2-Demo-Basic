import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule } from '@angular/router';

import { EmployeeItemComponent } from './employee/employee-item.component';
import { EmployeeService} from './services/employee.service.component';
import { AppRountingModule } from './app.routing.module';
import { routingComponent } from './app.routing.module';
import { EmployeeFilterPipe } from './employee/employee-filter.pipe';
import { AppComponent } from './app.component';

@NgModule({
  declarations: [
    AppComponent, EmployeeItemComponent,
    EmployeeFilterPipe, routingComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    AppRountingModule
  ],
  providers: [ EmployeeService ],
  bootstrap: [AppComponent]
})
export class AppModule { }
